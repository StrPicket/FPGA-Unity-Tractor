# Problemas conocidos y mejoras propuestas

Hallazgos de leer el código. No los he compilado ni simulado, así que cada punto indica su certeza. El código en `fpga/` se dejó **sin modificar**.

| # | Problema | Dónde | Efecto | Arreglo propuesto |
|---|---|---|---|---|
| 1 | El proceso TX tiene `PROCESS(bt_uart, sw_uart, ac_uart)` pero usa `rising_edge(CLOCK_50)` | `de10_lite.vhd` | Quartus lo sintetiza como lógica con reloj y funciona; en simulación **no transmite**, porque el proceso nunca despierta en el flanco (cierto) | Cambiar a `PROCESS(CLOCK_50)` |
| 2 | `.sdc` define relojes en `ADC_CLK_10`, `MAX10_CLK1_50`, `MAX10_CLK2_50`, que no existen en el diseño | `DE10_LITE_GSensor.sdc` | Avisos de TimeQuest y `CLOCK_50` sin restricción (cierto) | `create_clock -period 20.000 [get_ports CLOCK_50]` |
| 3 | `botones`, `switches` y `rx` entran sin sincronizador | `de10_lite.vhd` | Riesgo de metaestabilidad, sobre todo en `rx`, que el UART muestrea directo | Dos flip-flops en cadena por entrada |
| 4 | Sin debounce en botones y switches | `de10_lite.vhd` | Posibles bytes duplicados al presionar (probable) | Filtro de unos 10 ms |
| 5 | Sin cola de transmisión; `tx_ena` dura un ciclo | `de10_lite.vhd`, `uart.vhd` | Si llega un evento con el UART ocupado (86.8 µs) o dos eventos coinciden, se pierde (cierto, poco probable en uso humano) | Registro de pendientes o FIFO pequeña |
| 6 | El protocolo es por eventos, sin reenvío | Protocolo | Un byte perdido deja a Unity con estado viejo | Reenviar el estado cada ~100 ms (`clksec` ya divide a ~10 Hz) |
| 7 | Sin histéresis en los umbrales del acelerómetro (8 y 128) | `de10_lite.vhd` | Cerca del umbral, la zona puede oscilar (probable) | Dos umbrales por zona |
| 8 | Las lecturas de rx y tx usan flancos de señales internas como reloj (`falling_edge(rx_busy)`) | `de10_lite.vhd` | Funciona, pero genera relojes derivados y complica el análisis de tiempos | Detectar el flanco con un registro y `CLOCK_50` |
| 9 | UART sin reset (`reset_n` fijo en `'1'`) | `uart.vhd` | Depende de los valores iniciales al configurar la FPGA | Restaurar el puerto y conectarlo |
| 10 | Puerto `KEY` está en `B14`/`F15`, que parecen switches SW8/SW9 | `.qsf` | Confunde con los pulsadores `botones`. `KEY(0)` es el reset activo en bajo del acelerómetro (confirmado en `reset_delay.v`); que `B14` sea SW8 falta verificarlo en el manual | Renombrar a `RST_SW` |
| 11 | Dispositivo `10M50DAF484C6GES` en el `.qsf` | `.qsf` | Puede no coincidir con tu placa (por verificar) | Ajustar en *Assignments → Device* |
| 12 | `clksec.vhd` está en el proyecto y no se instancia; `test` y otras señales sin uso | varios | Ninguno, solo ruido | Quitar o usar |
| 13 | `comunicacion_ipregen.rpt` dice que el top es `DE10_LITE_GSensor`, y `filelist.txt` lista el `DE10_LITE_GSensor.v` original | reportes | Huellas del demo de Terasic. El top real es `de10_lite` | Ninguno |
| 14 | Zona no monótona: con X positivo, `abs = 4` → `l`, `abs = 5` → `X`, `abs ≥ 6` → `l`. Los umbrales comparan el valor numérico del patrón de LEDs | `de10_lite.vhd`, `led_driver.v` | Al inclinar despacio puede salir `l`, `X`, `l` (cierto, ver [acelerometro.md](acelerometro.md)) | Clasificar con el valor del sensor (`data_x`) en vez del patrón de LEDs |
| 15 | Un golpe o sacudida > 2 g activa INT2 y `led_driver` parpadea todos los LEDs ≈ 168 ms (`0x3FF`/`0x000`) | `led_driver.v`, `spi_ee_config.v` | Ráfaga `l r l r ...` espuria hacia Unity (probable, por lectura del código) | Ignorar la zona mientras `GSENSOR_INT(0) = '1'` o durante 170 ms, o quitar la interrupción de actividad |
| 16 | Solo se lee el eje X | `spi_ee_config.v` | No hay detección de otros movimientos | Ampliar la lectura si se necesitan Y o Z |

## Orden recomendado

1. **#2 y #1** son cambios de una línea y evitan avisos y simulaciones inútiles.
2. **#3 y #4** suben la robustez en hardware real.
3. **#5 y #6** si se observa que Unity se desincroniza.
4. El resto, por limpieza.

Para validar los cambios en simulación, el testbench más útil sería un bucle `tx → rx` con dos instancias de `uart` a 115200 baudios.
