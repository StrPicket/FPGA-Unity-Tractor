# Hardware y asignación de pines

Datos tomados de `fpga/comunicacion.qsf` (Quartus Prime Lite 18.1, creado el 27/nov/2023).

| Parámetro | Valor |
|---|---|
| Familia | MAX 10 |
| Dispositivo en el `.qsf` | `10M50DAF484C6GES` |
| Top-level entity | `de10_lite` |
| Reloj | `CLOCK_50` en `PIN_P11` |

> El `.qsf` apunta a `10M50DAF484C6GES`. Revisa en el manual de tu placa qué variante lleva; si Quartus se queja al programar, cambia el dispositivo en *Assignments → Device*.

## Pines

La columna "Componente de la placa" sale de mi lectura del manual de la DE10-Lite y **conviene verificarla** con el manual oficial.

### Entradas

| Puerto VHDL | Pin | Estándar de E/S | Componente de la placa |
|---|---|---|---|
| `CLOCK_50` | `PIN_P11` | 3.3-V LVTTL | Reloj de 50 MHz |
| `botones[0]` | `PIN_B8` | 3.3 V Schmitt trigger | Pulsador KEY0 |
| `botones[1]` | `PIN_A7` | 3.3 V Schmitt trigger | Pulsador KEY1 |
| `switches[0]` | `PIN_C10` | 3.3-V LVTTL | SW0 |
| `switches[1]` | `PIN_C11` | 3.3-V LVTTL | SW1 |
| `KEY[0]` | `PIN_B14` | 3.3-V LVTTL | Parece ser **SW8**, no un pulsador |
| `KEY[1]` | `PIN_F15` | 3.3-V LVTTL | Parece ser **SW9**, no un pulsador |
| `rx` | `PIN_AA8` | 3.3-V LVTTL | Header GPIO, viene del FTDI |
| `GSENSOR_INT[0]` | `PIN_Y13` | 3.3-V LVTTL | Interrupción del acelerómetro (el firmware la usa como INT2, a donde enruta la actividad) |
| `GSENSOR_INT[1]` | `PIN_Y14` | 3.3-V LVTTL | Interrupción 2 del acelerómetro |

### Salidas y bidireccionales

| Puerto VHDL | Pin | Componente |
|---|---|---|
| `tx` | `PIN_Y7` | Header GPIO, va al FTDI |
| `GSENSOR_CS_N` | `PIN_AB16` | Acelerómetro (SPI) |
| `GSENSOR_SCLK` | `PIN_AB15` | Acelerómetro (SPI) |
| `GSENSOR_SDI` | `PIN_V11` | Acelerómetro (SPI, línea de datos) |
| `GSENSOR_SDO` | `PIN_V12` | Acelerómetro (declarado `INOUT`, sin uso interno) |
| `LEDR[0..9]` | `A8, A9, A10, B10, D13, C13, E14, D14, A11, B11` | LEDR0–LEDR9 |
| `display[0..7]` | `C14, E15, C15, C16, E16, D17, C17, D15` | HEX0, segmentos a–g y punto |

`display(7)` es el punto decimal. `bcd7seg_sec` lo deja apagado.

## Un detalle importante: el puerto `KEY` no es un pulsador

En `de10_lite.vhd` hay **dos** juegos de entradas con nombres parecidos:

- `botones` en `B8` y `A7` son los **pulsadores** de la placa. Mandan `a` y `k`.
- `KEY` en `B14` y `F15` son, según el manual de la DE10-Lite, los switches **SW8 y SW9**. `KEY(0)` entra al módulo `reset_delay`, que genera el reset del acelerómetro.

En `fpga/v/reset_delay.v` la entrada `iRSTN` es **activa en bajo** (confirmado en el código): con `KEY(0) = '0'` el módulo del acelerómetro queda en reset, y con `'1'` se libera tras ≈ 21 ms. Por eso ese switch debe estar **arriba**. Lo que queda por verificar en el manual es que `PIN_B14` sea realmente SW8. Conviene renombrar el puerto a algo como `RST_SW` para evitar confusiones.

## Conexión del FTDI

| Módulo FTDI | FPGA | Pin |
|---|---|---|
| RX | `tx` | `PIN_Y7` |
| TX | `rx` | `PIN_AA8` |
| 3.3V | 3.3V (header) | — |
| GND | GND (header) | — |

El reporte original da esta tabla:

| FTDI | FPGA |
|---|---|
| RX | GPIO25 (pin header) |
| 3.3V | 3.3V (pin header) |
| GND | GND (pin header) |

y añade que su equipo agregó "una conexión más para TX" a otro GPIO sin decir cuál. Es coherente con este `.qsf`, donde el TX del FTDI va a `rx` (`PIN_AA8`). Los dos cruzan RX con TX, como corresponde.

**Antes de conectar:** verifica en el manual que `PIN_Y7` y `PIN_AA8` correspondan a los GPIO que usas, y que tu FTDI trabaje a **3.3 V**. Un FTDI a 5 V puede dañar el MAX 10.

## Archivos auxiliares del proyecto

| Archivo | Qué es | ¿En el repo? |
|---|---|---|
| `comunicacion.qpf` / `.qsf` | Proyecto y asignaciones de Quartus | Sí |
| `DE10_LITE_GSensor.sdc` | Restricciones de tiempo, heredadas del demo de Terasic | Sí (con problemas, ver [problemas-conocidos.md](problemas-conocidos.md)) |
| `comunicacion_assignment_defaults.qdf` | Valores por defecto, los regenera Quartus | No (en `.gitignore`) |
| `comunicacion.qws` | Estado de ventanas del IDE | No |
| `comunicacion_ipregen.rpt` | Reporte de actualización de IP: `spi_pll` (ALTPLL 16.0) se actualizó a Quartus 18.1 | No |
| `*.bak` | Respaldos de `de10_lite.vhd` y `uart.vhd` | No |
| `filelist.txt`, `out_directory_tmp_txt.tmp` | Listas del demo original de Terasic | No (ver [fpga/v/README.md](../fpga/v/README.md)) |

El respaldo `de10_lite_vhd.bak` muestra que el proyecto empezó como el demo `DE10_LITE_GSensor` de Terasic, que solo leía el acelerómetro y lo mostraba en los LEDR. El equipo le agregó UART, botones, switches y display.
