# Protocolo UART FPGA ↔ Unity

Todo lo de este documento sale de leer `fpga/de10_lite.vhd` y `fpga/uart.vhd`. Lo que es **inferencia** o **no verificado** está marcado así.

## Capa física

| Parámetro | Valor | Dónde está |
|---|---|---|
| Baud rate | 115 200 | `uart.vhd`, genérico `baud_rate` |
| Reloj del sistema | 50 MHz (`CLOCK_50`, `PIN_P11`) | genérico `clk_freq` |
| Datos | 8 bits, LSB primero | `d_width = 8` |
| Paridad | ninguna | `parity = 0` |
| Stop | 1 bit | |
| Sobremuestreo RX | 16× | `os_rate = 16` |
| Niveles | 3.3 V LVTTL | `.qsf` |

Con 50 MHz el divisor es `50 000 000 / 115 200 = 434` (entero), lo que da 115 207 baudios reales, un error de 0.006 %. Un byte completo (10 bits) tarda **86.8 µs**.

## FPGA → Unity

Es un protocolo **por eventos**. La FPGA manda **un byte** cuando algo cambia y no repite nada después. No hay encabezado, longitud ni checksum.

| Fuente | Evento que dispara el envío | Binario | Hex | ASCII |
|---|---|---|---|---|
| `botones(0)` (KEY0) | Flanco de bajada (se presiona; el botón es activo en bajo) | `01100001` | `0x61` | `a` |
| `botones(1)` (KEY1) | Igual | `01101011` | `0x6B` | `k` |
| `switches = "10"` | Cualquier cambio en `switches` que termine en ese valor | `01010000` | `0x50` | `P` |
| `switches = "11"` | Igual | `01001110` | `0x4E` | `N` |
| `switches = "01"` | Igual | `01010010` | `0x52` | `R` |
| `switches = "00"` | Igual | `01000100` | `0x44` | `D` |
| Acelerómetro, `LEDR_2 < 8` | La zona cambió | `01110010` | `0x72` | `r` |
| Acelerómetro, `LEDR_2 > 128` | La zona cambió | `01101100` | `0x6C` | `l` |
| Acelerómetro, entre 8 y 128 | La zona cambió | `01011000` | `0x58` | `X` |

`switches(1)` es el bit izquierdo. Así, `"10"` significa `SW1 = 1` y `SW0 = 0`.

**Inferencia (no documentada en el código):** `P`, `N`, `R`, `D` son las letras de una caja automática (Park, Neutral, Reverse, Drive). Las letras `a` y `k` no tienen significado evidente en el código.

### Zonas del acelerómetro

Las comparaciones se hacen sobre `LEDR_2`, el patrón de 10 bits que entrega `led_driver` (código de Terasic), **no** sobre la lectura cruda del sensor. Solo cuenta el **eje X**. X positivo (LEDR altos) manda `l`; X negativo (LEDR bajos) manda `r`. La tabla exacta, con sus rarezas, está en [acelerometro.md](acelerometro.md).

```vhdl
VARIABLE comp : STD_LOGIC_VECTOR(9 DOWNTO 0) := "0000000001";
-- zona 0 (manda 'r'):  LEDR_2 < comp(6 DOWNTO 0) & "000"   = 0000001000 = 8
-- zona 2 (manda 'l'):  LEDR_2 > comp(2 DOWNTO 0) & "0000000" = 0010000000 = 128
-- zona 1 (manda 'X'):  cualquier otro caso
```

El código compara vectores `std_logic_vector` con `<` y `>`. Sin `numeric_std`, VHDL lo hace en orden lexicográfico, que para vectores de la misma longitud con `'0'` y `'1'` equivale a una comparación sin signo.

### Prioridad

Si dos fuentes producen un evento **en el mismo ciclo de reloj**, solo se manda uno:

```
KEY0 (a)  >  KEY1 (k)  >  switches (P/N/R/D)  >  acelerómetro (l/r/X)
```

Los eventos de menor prioridad **se pierden**; no se encolan.

### Cuándo se puede perder un byte

El pulso `tx_ena` dura un ciclo de reloj (20 ns). El UART solo lo acepta si está en `idle`. Si ya está transmitiendo (86.8 µs por byte), el evento se descarta sin avisar. Con personas manipulando botones y switches es improbable, pero puede pasar con rebote mecánico, porque el diseño no tiene debounce.

## Unity → FPGA

Unity manda **un byte cualquiera**. Cuando termina la recepción (flanco de bajada de `rx_busy`), la FPGA guarda `rx_data` y muestra su **nibble bajo** (`inrx_data(3 downto 0)`) en `HEX0` como dígito hexadecimal `0`–`F`.

| Byte que manda Unity | Se ve en HEX0 |
|---|---|
| `0x00`–`0x0F` | `0`–`F` |
| `'0'`–`'9'` (`0x30`–`0x39`) | `0`–`9` |
| `'A'` (`0x41`) | `1` |
| `0xFF` | `F` |

**Inferencia:** el reporte dice que ese número es el que Unity manda a la FPGA para el display. Lo más probable es que sea el puntaje, y como solo se ve un nibble, solo cabe hasta `F` (15) o un dígito si manda ASCII. El script de Unity no está en el repo, así que **no está verificado**.

## Ejemplo de lectura en C# (no probado)

```csharp
using System.IO.Ports;

var port = new SerialPort("COM3", 115200, Parity.None, 8, StopBits.One);
port.Open();

// En Update() o en un hilo:
while (port.BytesToRead > 0)
{
    char c = (char)port.ReadByte();
    switch (c)
    {
        case 'l': /* inclinación izquierda */ break;
        case 'r': /* inclinación derecha   */ break;
        case 'X': /* inclinación al centro */ break;
        case 'P': case 'N': case 'R': case 'D': /* marcha = c */ break;
        case 'a': /* botón KEY0 */ break;
        case 'k': /* botón KEY1 */ break;
    }
}

// Mostrar un dígito en HEX0:
port.Write(new byte[] { (byte)('0' + score % 10) }, 0, 1);
```

Como el protocolo es por eventos, **Unity debe guardar el último valor de cada fuente** (última marcha, última zona de inclinación) y aplicarlo en cada frame. Un byte perdido deja a Unity con un estado viejo hasta el siguiente cambio.

## Pruebas rápidas sin Unity

Con un terminal serie (PuTTY, Tera Term, `screen`, `pyserial`) a 115200 8N1:

1. Cambia los switches: deben aparecer `P`, `N`, `R`, `D` según la combinación.
2. Presiona `KEY0` y `KEY1`: deben aparecer `a` y `k`.
3. Inclina la placa: deben aparecer `l`, `r` o `X` al cruzar los umbrales.
4. Escribe un dígito en el terminal: debe verse en `HEX0`.
