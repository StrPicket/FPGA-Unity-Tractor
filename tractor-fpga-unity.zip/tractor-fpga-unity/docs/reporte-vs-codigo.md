# El reporte contra el código

El reporte (`Reporte_Evidencia1_Equipo_original.pdf`) es de un equipo; el código de `fpga/` viene de **otro equipo** del mismo reto. Describen el mismo juego pero **no son la misma implementación**.

| Tema | Reporte | Código de este repo |
|---|---|---|
| Top level | `de10lite_GSensor` | `de10_lite` |
| Codificación a Unity | Enteros binarios `0`–`6` (`00000001` = izquierda, `00000011` = adelante, ...) | Letras ASCII: `a k P N R D l r X` |
| Adelante / atrás | `SW(0)` / `SW(1)` | Los dos switches forman una marcha `P/N/R/D` |
| Giro | Botón `KEY(0)` + bits de `LEDR`; **derecha** = `LEDR(9:6)`, **izquierda** = `LEDR(3:0)` | Acelerómetro siempre activo: `l`, `r`, `X`; **`l`** = LEDR altos, **`r`** = LEDR bajos (sentido **contrario** al reporte) |
| FSM de 5 estados | Sí (STOP, FORWARD, REVERSE, LEFT, RIGHT) | **No hay FSM en VHDL**: son detectores de evento y un árbitro de prioridad |
| Entidad `vga` y salida VGA | Sí | No existe |
| Display de 7 segmentos | Muestra el número que manda Unity | Igual (nibble bajo en `HEX0`) |
| UART | `tx_ena`, `tx_data`, `rx_busy`, `rx_data` | Igual, mismos nombres |
| Pin FTDI | `GPIO25` | `tx` = `PIN_Y7` |

## Qué hacer con la FSM del reporte

La FSM (STOP, FORWARD, REVERSE, LEFT, RIGHT) describe el comportamiento del **tractor**, no el del firmware de este repo. Con este código esa lógica tendría que vivir en **Unity**, que combinaría la última marcha (`P/N/R/D`) con la última zona de inclinación (`l/r/X`).

Si quieres conservar el diseño del reporte, el camino es reescribir el firmware para mandar los códigos `0`–`6`. Son dos protocolos distintos y no conviene mezclarlos.

## Errores del reporte que no hay que copiar al README

- "reactores" debe decir "tractores".
- Soft processor: no es "solo software". Es un procesador implementado en la lógica de la FPGA (por ejemplo, Nios II).
- Los inventores de la FPGA fueron Ross Freeman y Bernard Vonderschmitt (Xilinx), no "Von Der Schmitt".
- El título "Diseño del CPU" no corresponde al contenido: no se diseña ningún CPU.
- La FSM del reporte usa `KEY(0)='1'` para habilitar el giro, pero los botones de la placa son activos en bajo.
