# Acelerómetro: configuración y cómo se llega a `l`, `r` y `X`

Todo esto sale de leer `fpga/v/` (demo `DE10_LITE_GSensor` de Terasic) y `fpga/de10_lite.vhd`. No lo he simulado ni probado en la placa.

## Cadena de datos

```
ADXL345 ──SPI 3 hilos, 2 MHz──► spi_ee_config ──► data_x[15:0] ──► led_driver ──► LEDR_2[9:0] ──► zona (l / r / X) ──► UART
 (lee solo el eje X)            (init + lectura)   (10 bits útiles)  (patrón de LEDs)
```

- Solo se usa el **eje X**: `spi_ee_config` lee `X_LB` (`0x32`) y `X_HB` (`0x33`). Y y Z no se leen.
- `data_x(9 downto 0)` son los 10 bits del eje X (formato justificado a la derecha).
- `spi_pll` genera dos relojes de **2 MHz** (`c0` con 200° y `c1` con 120° de desfase) a partir de `CLOCK_50`.

## Registros que se escriben al arrancar (ADXL345)

Tabla de `spi_ee_config.v`, 11 escrituras (`INI_NUMBER = 11`):

| Registro | Dirección | Valor | Significado |
|---|---|---|---|
| `THRESH_ACT` | `0x24` | `0x20` | Umbral de actividad: 32 × 62.5 mg = **2 g** |
| `THRESH_INACT` | `0x25` | `0x03` | Umbral de inactividad |
| `TIME_INACT` | `0x26` | `0x01` | Tiempo de inactividad |
| `ACT_INACT_CTL` | `0x27` | `0x7F` | Actividad en X, Y, Z (acoplamiento DC) |
| `THRESH_FF` | `0x28` | `0x09` | Umbral de caída libre |
| `TIME_FF` | `0x29` | `0x46` | Tiempo de caída libre |
| `BW_RATE` | `0x2C` | `0x09` | **50 Hz** de tasa de datos |
| `INT_ENABLE` | `0x2E` | `0x10` | Solo interrupción de **actividad** |
| `INT_MAP` | `0x2F` | `0x10` | Actividad enrutada a **INT2** |
| `DATA_FORMAT` | `0x31` | `0x40` | SPI de **3 hilos**, rango **±2 g**, 10 bits |
| `POWER_CONTROL` | `0x2D` | `0x08` | Modo de medición |

Los significados de los bits salen de mi lectura de la hoja de datos del ADXL345; cotéjalos con ella.

## `led_driver`: de la lectura a un patrón de LEDs

1. Toma `iDIG[8:4]` (con `INT2` en bajo) como un valor de 5 bits con signo. Cada paso equivale a unos **62.5 mg**, y la escala se recorta a ±1 g.
2. Calcula una magnitud `abs` de 0 a 15 y el signo.
3. Devuelve este patrón en `LEDR`:

| `abs` | X negativo | X positivo |
|---|---|---|
| 0 | `0x030` | `0x030` |
| 1 | `0x010` | `0x020` |
| 2 | `0x018` | `0x060` |
| 3 | `0x008` | `0x040` |
| 4 | `0x00C` | `0x0C0` |
| 5 | `0x004` | `0x080` |
| 6 | `0x006` | `0x180` |
| 7 | `0x002` | `0x100` |
| 8 | `0x003` | `0x300` |
| 9 a 15 | `0x001` | `0x200` |

La burbuja se mueve hacia `LEDR[0]` con X negativo y hacia `LEDR[9]` con X positivo.

## De patrón a `l` / `r` / `X`

`de10_lite.vhd` no mira el ángulo: compara el **valor numérico del patrón de LEDs**.

```
LEDR_2 < 8     → 'r'
LEDR_2 > 128   → 'l'
en otro caso   → 'X'
```

Resultado exacto con la tabla de arriba:

| `abs` | X negativo | X positivo |
|---|---|---|
| 0 a 3 | `X` | `X` |
| 4 | `X` | **`l`** |
| 5 | **`r`** | `X` |
| 6 a 15 | **`r`** | **`l`** |

Aproximadamente: `l` aparece con X positivo desde ≈ +0.25 g, y `r` con X negativo desde ≈ −0.3 g. **X positivo (LEDR altos) manda `l`.**

## Dos comportamientos raros (por el diseño de la comparación)

1. **Zona no monótona.** Con X positivo, `abs = 4` da `l`, `abs = 5` da `X` (el patrón `0x080` vale justo 128, que no es mayor que 128) y `abs ≥ 6` vuelve a dar `l`. Al inclinar despacio puede aparecer `l`, `X`, `l`.
2. **Destello de actividad.** Si el acelerómetro detecta actividad (> 2 g en cualquier eje) activa `INT2`, y `led_driver` hace parpadear **todos** los LEDs durante ≈ 168 ms (`0x3FF` / `0x000` cada ≈ 21 ms). El top interpreta `0x3FF` como `l` y `0x000` como `r`, así que un golpe o sacudida fuerte manda una ráfaga `l r l r ...` a Unity.

Ver [problemas-conocidos.md](problemas-conocidos.md) para posibles arreglos.

## Reset

`KEY(0)` entra a `reset_delay` y es **activo en bajo**: mientras valga `'0'` el módulo del acelerómetro está en reset. Al pasar a `'1'` espera `2^20` ciclos (≈ 21 ms) antes de liberarlo. Por eso hay que mantener ese switch **arriba** (verifica en el manual qué switch es: el `.qsf` lo asigna a `PIN_B14`).
