# Arquitectura del firmware

## Jerarquía

```
de10_lite (top, VHDL)
├── reset_delay      (Terasic)   reset retardado, activo en bajo, entrada KEY(0)
├── spi_pll          (Intel)     dos relojes de 2 MHz (200° y 120°) desde CLOCK_50
├── spi_ee_config    (Terasic)   configura el ADXL345 y lee el eje X -> data_x[15:0]
│   └── spi_controller           SPI de 3 hilos
├── led_driver       (Terasic)   data_x[9:0] -> LEDR_2[9:0]
├── uart             (Digi-Key)  UART 8N1, 115200
└── bcd7seg_sec                  nibble -> HEX0 (activo en bajo)
```

Detalles del sensor y del patrón de LEDs: [acelerometro.md](acelerometro.md).

`clksec` está en el proyecto pero **no se instancia**. Divide el reloj a ~10 Hz (`50 MHz / (2 * 2 500 001)`); el nombre sugiere que se pensó para 1 s.

## Procesos de `de10_lite.vhd`

| Proceso | Reloj | Qué hace |
|---|---|---|
| Botones | `CLOCK_50` | Pulso de 1 ciclo (`bt_uart`) cuando un botón pasa a `'0'`. Se rearma al soltarlo. |
| Switches | `CLOCK_50` | Pulso (`sw_uart`) cuando `switches` cambia respecto al ciclo anterior. |
| Acelerómetro | `CLOCK_50` | Clasifica `LEDR_2` en zona 0, 1 o 2; pulso (`ac_uart`) cuando cambia la zona. |
| TX | `CLOCK_50` (la lista de sensibilidad no lo dice, ver problemas) | Arbitra con prioridad `bt0 > bt1 > sw > ac`, carga `tx_data` y baja `tx_ena`. |
| RX | flanco de bajada de `rx_busy` | Guarda `rx_data` en `inrx_data` para el display. |
| `tx_busy` | flanco de bajada de `tx_busy` | Pone `test <= '1'`. **Código muerto:** `test` no se usa. |

## `tx_ena` es activo en bajo (modificación local)

El `uart.vhd` original de Scott Larson inicia la transmisión con `tx_ena = '1'`. En este proyecto la condición se invirtió:

```vhdl
IF(tx_ena = '0') THEN   -- nueva transacción
```

Por eso el top pone `tx_ena <= '0'` para mandar y `'1'` en reposo. No es un error: es una decisión del equipo, pero hay que recordarla si se reemplaza `uart.vhd` por otra versión.

## Otras diferencias contra el `uart.vhd` original

Comparado con `uart_vhd.bak`, el archivo actual:

- Quita el puerto `reset_n` y lo vuelve una señal interna fija en `'1'`, así que el UART **nunca se resetea**.
- Mantiene el encabezado de Digi-Key. Si se publica, hay que conservarlo.

## Señales y código sin uso

`LEDR_2_anterior`, `botones_anterior`, `switches_anterior`, `rx_error`, `test`, `flag_sw` y `switches_prev` declaradas dentro del proceso de botones, y `comp` en el proceso TX (se usa, pero duplica el del proceso del acelerómetro). Se pueden limpiar sin cambiar el comportamiento.
